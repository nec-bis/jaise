(function() {
var toc =  [{"type":"item","name":"Viewing and Managing Job Queue","url":"ACIC_ISM/03_Managing_Transactions/03_Managing_Transactions.htm#TOC_Viewing_and_Managing_Jobbc-1"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();