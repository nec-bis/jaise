(function() {
var toc =  [{"type":"item","name":"Adding a Watchlist","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Adding_a_Watchlistbc-23"},{"type":"item","name":"Deleting a Watchlist","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Deleting_a_Watchlistbc-24"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();