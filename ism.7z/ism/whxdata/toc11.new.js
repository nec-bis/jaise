(function() {
var toc =  [{"type":"item","name":"Adding a Domain","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Adding_a_Domainbc-11"},{"type":"item","name":"Editing a Domain","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Editing_a_Domainbc-12"},{"type":"item","name":"Deleting a Domain","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Deleting_a_Domainbc-13"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();