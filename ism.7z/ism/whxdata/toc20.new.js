(function() {
var toc =  [{"type":"item","name":"Workflow Definition","url":"ACIC_ISM/06_Managing_Application_Configurations/06_Managing_Application_Configurations.htm#TOC_Workflow_Definitionbc-14"},{"type":"item","name":"Workflow Deployment","url":"ACIC_ISM/06_Managing_Application_Configurations/06_Managing_Application_Configurations.htm#TOC_Workflow_Deploymentbc-15"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();