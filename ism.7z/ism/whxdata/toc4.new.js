(function() {
var toc =  [{"type":"item","name":"Performing a Simple Keyword Search","url":"ACIC_ISM/02_Navigating_the_Application/02_Navigating_the_Application.htm#TOC_Performing_a_Simplebc-8"},{"type":"item","name":"Performing an Advanced Search","url":"ACIC_ISM/02_Navigating_the_Application/02_Navigating_the_Application.htm#TOC_Performing_an_Advancedbc-9"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();