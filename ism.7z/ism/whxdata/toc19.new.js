(function() {
var toc =  [{"type":"item","name":"Uploading a Report Template","url":"ACIC_ISM/06_Managing_Application_Configurations/06_Managing_Application_Configurations.htm#TOC_Uploading_a_Reportbc-12"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();