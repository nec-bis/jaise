(function() {
var toc =  [{"type":"item","name":"Adding an Agency","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Adding_an_Agencybc-26"},{"type":"item","name":"Editing an Agency","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Editing_an_Agencybc-27"},{"type":"item","name":"Deleting an Agency","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Deleting_an_Agencybc-28"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();