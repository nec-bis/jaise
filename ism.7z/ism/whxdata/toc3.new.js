(function() {
var toc =  [{"type":"item","name":"Managing Messages","url":"ACIC_ISM/02_Navigating_the_Application/02_Navigating_the_Application.htm#TOC_Managing_Messagesbc-4"},{"type":"item","name":"Managing Alerts","url":"ACIC_ISM/02_Navigating_the_Application/02_Navigating_the_Application.htm#TOC_Managing_Alertsbc-5"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();