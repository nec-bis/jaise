(function() {
var toc =  [{"type":"item","name":"Adding a Device","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Adding_a_Devicebc-19"},{"type":"item","name":"Editing a Device","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Editing_a_Devicebc-20"},{"type":"item","name":"Deleting a Device","url":"ACIC_ISM/05_Performing_Administrative_Tasks/05_Performing_Administrative_Tasks.htm#TOC_Deleting_a_Devicebc-21"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();